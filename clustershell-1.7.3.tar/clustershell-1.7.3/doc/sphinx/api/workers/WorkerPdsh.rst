WorkerPdsh
----------

.. py:currentmodule:: ClusterShell.Worker.Pdsh

.. autoclass:: WorkerPdsh
    :members:
    :special-members:

.. autoclass:: PdshClient
    :members:
    :special-members:

.. autoclass:: PdcpClient
    :members:
    :special-members:
