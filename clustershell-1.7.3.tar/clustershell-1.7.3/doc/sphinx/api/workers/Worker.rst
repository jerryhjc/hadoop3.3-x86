Worker
------

.. automodule:: ClusterShell.Worker.Worker
.. py:currentmodule:: ClusterShell.Worker.Worker

.. autoclass:: Worker
    :members:
    :special-members:

.. autoclass:: DistantWorker
    :members:
    :special-members:
