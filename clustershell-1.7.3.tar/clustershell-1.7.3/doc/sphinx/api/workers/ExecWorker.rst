ExecWorker
----------

.. py:currentmodule:: ClusterShell.Worker.Exec

.. autoclass:: ExecWorker
    :members:
    :special-members:

.. autoclass:: ExecClient
    :members:
    :special-members:

