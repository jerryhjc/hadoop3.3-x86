WorkerPopen
-----------

.. py:currentmodule:: ClusterShell.Worker.Popen

.. autoclass:: WorkerPopen
    :members:
    :special-members:

.. autoclass:: PopenClient
    :members:
    :special-members:

