StreamWorker
------------

.. py:currentmodule:: ClusterShell.Worker.Worker

.. autoclass:: StreamWorker
    :members:
    :special-members:

.. autoclass:: StreamClient
    :members:
    :special-members:
