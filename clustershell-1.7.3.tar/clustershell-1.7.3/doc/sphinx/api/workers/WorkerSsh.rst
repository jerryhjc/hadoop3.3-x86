WorkerSsh
---------

.. py:currentmodule:: ClusterShell.Worker.Ssh

.. autoclass:: WorkerSsh
    :members:
    :special-members:

.. autoclass:: SshClient
    :members:
    :special-members:

.. autoclass:: ScpClient
    :members:
    :special-members:
