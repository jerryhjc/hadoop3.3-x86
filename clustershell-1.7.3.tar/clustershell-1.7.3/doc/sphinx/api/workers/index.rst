Workers
=======

ClusterShell public Workers API autodoc.

Notes:

* Workers named *NameWorker* are new-style workers.
* Workers named *WorkerName* are old-style workers.

Contents:

.. toctree::
    :maxdepth: 2

    Worker
    ExecWorker
    StreamWorker
    WorkerRsh
    WorkerPdsh
    WorkerPopen
    WorkerSsh
