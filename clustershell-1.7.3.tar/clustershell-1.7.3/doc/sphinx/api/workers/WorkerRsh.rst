WorkerRsh
---------

.. py:currentmodule:: ClusterShell.Worker.Rsh

.. autoclass:: WorkerRsh
    :members:
    :special-members:

.. autoclass:: RshClient
    :members:
    :special-members:

.. autoclass:: RcpClient
    :members:
    :special-members:
