Defaults
--------

.. automodule:: ClusterShell.Defaults
.. py:currentmodule:: ClusterShell.Defaults


.. autoclass:: Defaults
    :members:

.. data:: DEFAULTS

Globally accessible :class:`Defaults` object.
