RangeSet
--------

.. automodule:: ClusterShell.RangeSet

.. py:currentmodule:: ClusterShell.RangeSet
.. autoclass:: RangeSet
    :members:
    :special-members:

RangeSetND
----------

.. autoclass:: RangeSetND
    :members:
    :special-members:

