EngineTimer
-----------

.. py:currentmodule:: ClusterShell.Engine.Engine

.. autoclass:: EngineTimer
    :members:
    :inherited-members:
    :special-members:
