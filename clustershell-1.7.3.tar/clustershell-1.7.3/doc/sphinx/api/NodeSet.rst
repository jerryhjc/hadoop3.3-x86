NodeSet
-------

.. automodule:: ClusterShell.NodeSet
.. py:currentmodule:: ClusterShell.NodeSet
.. autoclass:: NodeSet
    :members:
    :special-members:
    :inherited-members:

.. autofunction:: expand
.. autofunction:: fold
.. autofunction:: grouplist
.. autofunction:: std_group_resolver
.. autofunction:: set_std_group_resolver
