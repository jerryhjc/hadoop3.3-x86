MsgTree
-------

.. automodule:: ClusterShell.MsgTree
.. py:currentmodule:: ClusterShell.MsgTree
.. autoclass:: MsgTree
    :members:
    :special-members:

