Event
-----

.. automodule:: ClusterShell.Event
.. py:currentmodule:: ClusterShell.Event


.. autoclass:: EventHandler
    :members:
    :member-order: bysource
