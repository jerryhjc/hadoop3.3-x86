Task
----

.. automodule:: ClusterShell.Task
.. py:currentmodule:: ClusterShell.Task
.. autoclass:: Task
    :members:
    :special-members:

.. autofunction:: task_self
.. autofunction:: task_wait
.. autofunction:: task_terminate
.. autofunction:: task_cleanup
