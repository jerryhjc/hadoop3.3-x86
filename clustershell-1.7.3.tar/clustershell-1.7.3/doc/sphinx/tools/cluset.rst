.. _cluset-tool:

cluset
------

.. highlight:: console

The *cluset* command is the same as :ref:`nodeset-tool` and has been added
in ClusterShell 1.7.3 to avoid a conflict with xCAT's nodeset command.

